/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainingGroup;


import java.util.ArrayList;
import java.util.Random;


import Exceptions.NoSuchTrainingGroupException;

/**
 * 
 * Generate a random Training Group from a random leagues
 *
 * @author Tolga Baris Pinar
 */
public class TrainingGroupFactory {
    
    private static TrainingGroupType[] allTrainingGroupType;
    
    public TrainingGroupFactory(){
        
        this.allTrainingGroupType = TrainingGroupType.values();
    
    }
    
    /**
     * Generate a random Training Group from a random league
     *
     * @return a Training Group generated
     */
    public TrainingGroup getTrainingGroup() {

        League[] allLeagues = League.values();
        Random r = new Random();

        int randomLeagueNo = r.nextInt(allLeagues.length);

        return getTrainingGroup(allLeagues[randomLeagueNo]);
    }
    

  
    /**
     *
     * @param leag the league specified
     * @return a random TrainingGroup from department @param leag
     */
    public TrainingGroup getTrainingGroup(League leag) {

        ArrayList<TrainingGroupType> someTypes = new ArrayList<TrainingGroupType>();
        Random r = new Random();

        someTypes = leag.listAllTypes();

        int randomNo = r.nextInt(someTypes.size());

        TrainingGroup selected = someTypes.get(randomNo).getTrainingGroup();

        return selected;
    }
    
    
    
    /**
     * Create a TrainingGroup of a specified type
     *
     * @param groupType - the GroupType required
     * @return the TrainingGroup generated
     */
    private TrainingGroup getTrainingGroup(TrainingGroupType groupType) {

        return groupType.getTrainingGroup();
    }
    
    /**
     *
     * @return a formatted list of all available departments
     */
    public String listLeagues() {

        String leags = "";
        int counter = 1;

        for (League d : League.values()) {

            leags = leags.concat(counter + ": " + d.toString() + "\n");
            counter++;
        }

        return leags;
    }
    
    /**
     * Creates a TrainingGroup based on the type requested
     *
     * @param typeAsString - the TrainingGroup required, as a String
     * @return the TrainingGroup generated
     * @throws NoSuchTrainingGroupException if there is no type matching the request
     */
    public TrainingGroup getTrainingGroup(String typeAsString) throws NoSuchTrainingGroupException {

        int counter = 0;

        while ((counter < allTrainingGroupType.length) && (!typeAsString.equalsIgnoreCase(allTrainingGroupType[counter].toString()))) {

            counter++;
        }

        if (typeAsString.equalsIgnoreCase(allTrainingGroupType[counter].toString())) {

            return getTrainingGroup(allTrainingGroupType[counter]);
        } else {

            throw new NoSuchTrainingGroupException();
        }
    }
    
    
    
    
    
}
