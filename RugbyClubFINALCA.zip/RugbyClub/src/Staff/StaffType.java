/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Staff;

import java.util.ArrayList;

import NameGenerators.NameGenerator;
import ClubStaff.*;
import CoachingStaff.*;

/**
 * staff types
 *
 * @author Tolga Baris Pinar
 */
public enum StaffType {

    GROUNDSTAFF {

        @Override
        public Staff getStaff() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new GroundStaff(name[0], name[1]);

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public Department whichDept() {

            return Department.CLUBSTAFF;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Ground Staff";
        }

    },
    JANITOR {

        @Override
        public Staff getStaff() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new Janitor(name[0], name[1]);

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public Department whichDept() {

            return Department.CLUBSTAFF;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Janitor";
        }

    },
    RECEPTIONIST {

        @Override
        public Staff getStaff() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new Receptionist(name[0], name[1]);

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public Department whichDept() {

            return Department.CLUBSTAFF;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Receptionist";
        }

    },
    
    ASSISTANTCOACH {

        @Override
        public Staff getStaff() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new AssistantCoach(name[0], name[1]);

        }

        /**
         *
         * @return coachingStaffs for all CoachingStaff sub-types
         */
        @Override
        public Department whichDept() {

            return Department.COACHINGSTAFF;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Assistant Coach";
        }
    },
    STAMINACOACH {

        @Override
        public Staff getStaff() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new StaminaCoach(name[0], name[1]);

        }

        /**
         *
         * @return coachingStaffs for all CoachingStaff sub-types
         */
        @Override
        public Department whichDept() {

            return Department.COACHINGSTAFF;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Stamina Coach";
        }

    },
    
    HEADCOACH {

        @Override
        public Staff getStaff() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new HeadCoach(name[0], name[1]);

        }

        /**
         *
         * @return coachingStaffs for all CoachingStaff sub-types
         */
        @Override
        public Department whichDept() {

            return Department.COACHINGSTAFF;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Head Coach";
        }

    }    ;

    
    
    
    public abstract Staff getStaff();

    public abstract Department whichDept();

    private static String[] generateName() {

        NameGenerator NG = new NameGenerator();

        
        String name = NG.getRandomName();

        return name.split(" ");
    }

    //@return arraylist of only club staff roles
    public static ArrayList<StaffType> listClubStaff() {

        StaffType[] allTypes = StaffType.values();
        ArrayList<StaffType> clubStaffs = new ArrayList<StaffType>();

        for (StaffType t : allTypes) {

            if (t.whichDept() == Department.CLUBSTAFF) {
                clubStaffs.add(t);
            }
        }

        return clubStaffs;
    }

    //@return arraylist of only coaching staff roles
    public static ArrayList<StaffType> listCoachingStaff() {

        StaffType[] allTypes = StaffType.values();
        ArrayList<StaffType> coachingStaffs = new ArrayList<StaffType>();

        for (StaffType t : allTypes) {

            if (t.whichDept() == Department.COACHINGSTAFF) {
                coachingStaffs.add(t);
            }
        }

        return coachingStaffs;
    }
    
   

    /**
     *
     * @return All available types as a formatted multi-line String
     */
    public static String listStaffTypesAsString() {

        String list = "";
        StaffType[] types = StaffType.values();

        for (int counter = 0; counter < types.length; counter++) {

            list = list.concat((counter + 1) + " - " + types[counter].toString() + "\n");
        }

        return list;
    }
    
    

}
