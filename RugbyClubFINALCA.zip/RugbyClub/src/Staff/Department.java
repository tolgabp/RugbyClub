/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Staff;

import java.util.ArrayList;

/**
 *
 * Departments
 *
 * @author Tolga Baris Pinar
 */
public enum Department {

    CLUBSTAFF {

        @Override
        public Staff getStaff(StaffType type) {

            return type.getStaff();
        }

        @Override
        public ArrayList<StaffType> listAllTypes() {

            return StaffType.listClubStaff();
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Club Staff Department";
        }

    },
    COACHINGSTAFF {

        @Override
        public Staff getStaff(StaffType type) {

            return type.getStaff();
        }

        @Override
        public ArrayList<StaffType> listAllTypes() {

            return StaffType.listCoachingStaff();
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Coaching Staff Department";
        }

    };

    //@return a Staff of a specific type
    public abstract Staff getStaff(StaffType type);

    public abstract ArrayList<StaffType> listAllTypes();

    public abstract String toString();
}
