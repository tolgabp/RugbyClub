package NameGenerators;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;


import java.util.Random;
import java.util.Scanner;


/**
 * Base class to generate random names first names - array of Strings that could
 * be first names surnames
 * 
 * getFName() gets names from the text file.
 * 
 * getSurname() gets names from the text file.
 *
 * getRandomName() generates a random full name using these arrays
 *
 * @author Ken
 */
public class NameGenerator {

    private ArrayList<String> fList = new ArrayList<>();
    private ArrayList<String> sList = new ArrayList<>();
    private String[] firstNames;
    private String[] surnames;

    public NameGenerator() {
        //nothing here - deliberate
    }

    public String[] getFName() throws FileNotFoundException {

        try {
            Scanner s1 = new Scanner(new File("first-names.txt"));

            while (s1.hasNext()) {
                this.fList.add(s1.next());
            }
            s1.close();
            this.firstNames = new String[fList.size()];
            for (int i = 0; i < fList.size(); i++) {
                this.firstNames[i] = fList.get(i);
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred. Contact your service provider.");
        }
        return this.firstNames;
    }

    public String[] getSurname() throws FileNotFoundException {

        try {
            Scanner s2 = new Scanner(new File("last-names.txt"));

            while (s2.hasNext()) {
                this.sList.add(s2.next());
            }
            s2.close();

            this.surnames = new String[sList.size()];
            for (int i = 0; i < sList.size(); i++) {
                this.surnames[i] = sList.get(i);
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred. Contact your service provider.");
        }
        return this.surnames;
    }

    /**
     * Generates a random name using first names and surnames
     *
     * @return the name as a String
     */
    public String getRandomName() {

        Random r = new Random();

        try {
            getFName();
            getSurname();
        } catch (FileNotFoundException ex) {
            
        }
        
        String fName = this.firstNames[r.nextInt(firstNames.length)];
        String sName = this.surnames[r.nextInt(surnames.length)];
        return (fName + " " + sName);

    }

}


