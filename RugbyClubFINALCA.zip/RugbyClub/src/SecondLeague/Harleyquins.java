/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SecondLeague;

import TrainingGroup.League;
import TrainingGroup.SecondLeague;
import TrainingGroup.TrainingGroupType;

/**
 * 
 * Harleyquins extends SecondLeague
 *
 * @author Tolga Baris Pinar
 */
public class Harleyquins extends SecondLeague{
    
    public Harleyquins(int numOfPlayers) {
        super(numOfPlayers, TrainingGroupType.HARLEQUINS);
    }
    
  
    
}
