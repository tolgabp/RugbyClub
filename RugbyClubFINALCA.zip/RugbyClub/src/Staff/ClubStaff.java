/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Staff;

/**
 *
 * class ClubStaff extends Staff 
 * 
 * @author Tolga Baris Pinar
 */
public abstract class ClubStaff extends Staff {
    
    public ClubStaff(String firstname, String surname, StaffType role) {
        
        super(firstname, surname, Department.CLUBSTAFF, role);
    }
   
    /**
     * As there is a difference between club staff and coaching staff, it should
     * be put in the sub class of the parent class.
     *
     */
    
    
   @Override
    //return the Club staff member's name in full
    public String toString() {

        return "\n********* \nStaff ID: " + this.getStaff_ID()
                + "\nFirstname: " + this.getfirstName()
                + "\nSurname: " + this.getSurname()
                + "\nRole: " + this.getRole().toString();
             
    }
    
}
