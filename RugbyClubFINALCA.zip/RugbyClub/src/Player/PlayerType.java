/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Player;

import NameGenerators.NameGenerator;
import java.util.ArrayList;

/**
 *
 * @author Tolga Baris Pinar
 */
public enum PlayerType {

    LOOSEHEADPROP {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new LooseHeadProp(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Loose Head Prop";
        }

    },
    HOOKER {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new Hooker(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Hooker";
        }

    },
    TIGHTHEADPROP {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new TightHeadProp(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Tight Head Prop";
        }

    },
    SECONDROW {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new SecondRow(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Second Row";
        }

    },
    BLINDSIDEFLANKER {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new BlindSideFlanker(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Blind Side Flanker";
        }

    },
    OPENSIDEFLANKER {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new OpenSideFlanker(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Open Side Flanker";
        }

    },
    NUMBER8 {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new Number8(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Number 8";
        }

    },
    SCRUMHALF {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new ScrumHalf(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Scrum Half";
        }

    },
    FLYHALF {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new FlyHalf(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Fly Half";
        }

    },
    LEFTWING {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new LeftWing(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "LeftWing";
        }

    },
    INSIDECENTER {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new InsideCenter(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Inside Center";
        }
    },
    OUTSIDECENTER {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new OutsideCenter(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Outside Center";
        }
    },
    RIGHTWING {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new RightWing(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Right Wing";
        }
    },
    FULLBACK {

        @Override
        public Player getPlayer() {

            NameGenerator NG = new NameGenerator();

            String[] name = generateName();

            return new FullBack(name[0], name[1]);

        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Full Back";
        }
    };

    public abstract Player getPlayer();

    private static String[] generateName() {

        NameGenerator NG = new NameGenerator();

        String name = NG.getRandomName();

        return name.split(" ");
    }

    //@return arraylist of all player positions
    public static ArrayList<PlayerType> listPlayerType() {

        PlayerType[] allTypes = PlayerType.values();
        ArrayList<PlayerType> players = new ArrayList<PlayerType>();

        return players;
    }

    /**
     *
     * @return All available types as a formatted multi-line String
     */
    public static String listPlayerTypesAsString() {

        String list = "";
        PlayerType[] types = PlayerType.values();

        for (int counter = 0; counter < types.length; counter++) {

            list = list.concat((counter + 1) + ": " + types[counter].toString() + "\n");
        }

        return list;
    }

    public abstract String toString();
}
