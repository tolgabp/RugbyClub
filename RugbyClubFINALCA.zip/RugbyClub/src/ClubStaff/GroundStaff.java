/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClubStaff;

import Staff.StaffType;
import Staff.ClubStaff;

/**
 *
 * GroundStaff extends ClubStaff
 * 
 * @author Tolga Baris Pinar
 */


public class GroundStaff extends ClubStaff {
    
    public GroundStaff(String firstname, String surname) {
        super(firstname, surname, StaffType.GROUNDSTAFF);
    }
    
    
    
   
    
}


