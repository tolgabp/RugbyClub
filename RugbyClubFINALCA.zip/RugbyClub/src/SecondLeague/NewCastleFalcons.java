/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SecondLeague;

import TrainingGroup.League;
import TrainingGroup.SecondLeague;
import TrainingGroup.TrainingGroupType;

/**
 * 
 * NewCastleFalcons extends SecondLeague
 *
 * @author Tolga Baris Pinar
 */
public class NewCastleFalcons extends SecondLeague{
    
    public NewCastleFalcons(int numOfPlayers) {
        super(numOfPlayers, TrainingGroupType.NEWCASTLEFALCONS);
    }
    
    
}
