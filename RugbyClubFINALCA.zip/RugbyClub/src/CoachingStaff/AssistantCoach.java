/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CoachingStaff;

import Staff.CoachingStaff;
import Staff.StaffType;
/**
 *
 *AssistantCoach extends CoachingStaff 
 * 
 * @author Tolga Baris Pinar
 */
public class AssistantCoach extends CoachingStaff {
    
    public AssistantCoach(String firstname, String surname) {
        super(firstname, surname, StaffType.ASSISTANTCOACH);
    }
    
}
