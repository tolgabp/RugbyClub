/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rugbyclub;

import Menu.Menu;
import NameGenerators.NameGenerator;
import Player.Player;
import Player.PlayerFactory;
import Player.PlayerType;
import java.util.ArrayList;

import Staff.Staff;
import java.util.Scanner;
import Staff.StaffType;
import Staff.StaffFactory;
import TrainingGroup.League;
import TrainingGroup.TrainingGroup;
import TrainingGroup.TrainingGroupFactory;
import TrainingGroup.TrainingGroupType;

/**
 *
 * @author Tolga Baris Pinar
 */
public class RugbyClub {

    private ArrayList<Staff> staffList;
    private ArrayList<TrainingGroup> trainingGroupList;
    private ArrayList<Player> playerList;

    public RugbyClub() {

        this.staffList = new ArrayList<Staff>();
        createStaff(50);

        this.playerList = new ArrayList<Player>();
        createPlayer(300);

        this.trainingGroupList = new ArrayList<TrainingGroup>();
        createTrainingGroup(20);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        NameGenerator ng = new NameGenerator();

        //creates a new object of the Menu class and assigns it to the menu variable
        //so that one can use the methods of the Menu class
        Menu menu = new Menu();

        Scanner myKB = new Scanner(System.in);

        RugbyClub myRugbyClub = new RugbyClub();

        menu.menuDisplay();

    }

    /**
     * Generate a number of random staff members and populate staffList
     *
     * @param numStaff - the number of Staff wanted
     */
    private void createStaff(int numStaff) {

        StaffFactory myStaffFactory = new StaffFactory();

        for (int i = 0; i < numStaff; i++) {

            Staff newStaff = myStaffFactory.getStaff();

            this.staffList.add(newStaff);

        }

    }

    /**
     * Generate a number of random training groups and populate
     * trainingGroupList
     *
     * @param numTrainingGroup - the number of TrainingGroups wanted
     */
    private void createTrainingGroup(int numTrainingGroup) {

        TrainingGroupFactory myTrainingGroupFactory = new TrainingGroupFactory();
        int day_counter = 0;
        int coach_counter = 0;
        int player_counter_start = 0;
        int player_counter_end = 15;
        ArrayList<Staff> coachList = getCoachList();
        String[] weekDays = {"MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"};

        for (int i = 0; i < numTrainingGroup; i++) {

            TrainingGroup newTrainingGroup = myTrainingGroupFactory.getTrainingGroup();

            this.trainingGroupList.add(newTrainingGroup);
            this.trainingGroupList.get(i).setTrainingDay(weekDays[day_counter]);
            this.trainingGroupList.get(i).setCoach(coachList.get(coach_counter));
            while (player_counter_start < player_counter_end) {
                this.trainingGroupList.get(i).addGroupPlayer(playerList.get(player_counter_start));
                player_counter_start++;
            }
            player_counter_end = player_counter_end + 15;
            coach_counter++;
            day_counter++;
            if (day_counter == 7) {
                day_counter = 0;
            }
            if (coach_counter == coachList.size() - 1) {
                coach_counter = 0;
            }

        }

    }

    /**
     * Generate a number of random staff members and populate staffList
     *
     * @param numPlayer - the number of StaffMembers wanted
     */
    private void createPlayer(int numPlayer) {

        PlayerFactory myPlayerFactory = new PlayerFactory();

        for (int i = 0; i < numPlayer; i++) {

            Player newPlayer = myPlayerFactory.getPlayer();

            this.playerList.add(newPlayer);

        }

    }

    /**
     * Generates a formatted string that contains the details of all staff
     * working in the club
     *
     * @return the formatted string
     */
    public String listAllPlayer() {

        String list = "";

        for (Player p : playerList) {

            list = list.concat(p.toString());

        }

        return list;
    }

    /**
     * Generates a formatted string that contains the details of all staff
     * working in the club
     *
     * @return the formatted string
     */
    public String listAllStaff() {

        String list = "";

        for (Staff s : staffList) {

            list = list.concat(s.toString());

        }

        return list;
    }

    /**
     * Generates a formatted string that contains the details of all staff
     * working in the club
     *
     * @return the formatted string
     */
    public String listAllTrainingGroup() {

        String list = "";

        for (TrainingGroup tg : trainingGroupList) {

            list = list.concat(tg.toString());

        }

        return list;
    }

    /**
     *
     * @return a formatted String listing all staff types working in this club
     */
    public String getStaffTypes() {

        return StaffType.listStaffTypesAsString();

    }

    /**
     *
     * @return a formatted String listing all staff types working in this club
     */
    public String getTrainingGroupTypes() {

        return TrainingGroupType.listTrainingGroupTypesAsString();

    }

    /**
     *
     * @return a formatted String listing all staff types working in this club
     */
    public String getPlayerTypes() {

        return PlayerType.listPlayerTypesAsString();

    }

    // SUB MENU (2) 
    public void displayStaff(StaffType type) {
        for (Staff staff : staffList) {
            if (staff.getRole() == type) {
                staff.displayStaff();
            }
        }
    }

    //to display GroupByDayTrain
    public void displayGroupByDayTrain() {
        String[] weekDays = {"MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"};

        for (int i = 0; i < 7; i++) {
            System.out.println("\n" + "*****  " + weekDays[i] + "  *****");
            for (TrainingGroup trainingGroup : trainingGroupList) {
                if (trainingGroup.getTrainingDay() == weekDays[i]) {
                    System.out.println(trainingGroup.toString());
                }
            }
        }
    }

    //to display LeaguePlayer
    public void displayLeaguePlayer(League league) {
        for (TrainingGroup trainingGroup : trainingGroupList) {
            if (trainingGroup.getLeague() == league) {
                System.out.println(trainingGroup.toString());
            }
        }
    }

    public ArrayList<Staff> getCoachList() {
        ArrayList<Staff> result = new ArrayList<Staff>();
        
        //loop to iterate through each Staff object in the staffList collection
        for (Staff staff : staffList) {
            if (staff.getRole() == StaffType.ASSISTANTCOACH || staff.getRole() == StaffType.HEADCOACH || staff.getRole() == StaffType.STAMINACOACH) {
                result.add(staff);
            }
        }
        return result;
    }

    public void displayPlayerByCoach(Staff coach) {
        
        //loop to iterate through each TrainingGroup object in the trainingGroup collection
        for (TrainingGroup trainingGroup : trainingGroupList) {
            if (trainingGroup.getCoach().getStaff_ID() == coach.getStaff_ID()) {
                for (Player groupPlayers : trainingGroup.getGroupPlayers()) {
                    System.out.println(groupPlayers.toString() + "\n");
                }
            }
        }
    }
}
