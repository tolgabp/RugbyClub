/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package TrainingGroup;

import FirstLeague.*;
import SecondLeague.*;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Tolga Baris Pinar
 */
public enum TrainingGroupType {

    BALLYMENA {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Ballymena(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Ballymena R.F.C.";
        }

    },
    BALLYNAHINCH {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Ballynahinch(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Ballynahinch R.F.C.";
        }

    },
    BATH {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Bath(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Bath R.F.C.";
        }

    },
    BRISTOLBEARS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new BristolBears(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Bristol Bears R.F.C.";
        }

    },
    EXETERCHIEFS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new ExeterChiefs(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Exeter Chiefs R.F.C.";
        }

    },
    GLOUCESTER {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Gloucester(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Gloucester R.F.C.";
        }

    },
    CLONTARF {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Clontarf(1);

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Clontarf R.F.C.";
        }

    },
    HARLEQUINS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Harleyquins(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Harleyquins R.F.C.";
        }

    },
    GALWEGIANS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Galwegians(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Galwegians R.F.C.";
        }

    },
    INSTONIANS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Instonians(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Instonians R.F.C.";
        }

    },
    LEICESTERTIGERS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new LeicesterTigers(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Ballymena R.F.C.";
        }

    },
    LEINSTERRUGBY {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new LeinsterRugby(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Leinster Rugby R.F.C.";
        }

    },
    LONDONIRISH {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new LondonIrish(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "London Irish R.F.C.";
        }

    },
    WASPS {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new Wasps(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Wasps R.F.C.";
        }

    },
    CORNISHPIRATES {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new CornishPirates(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Cornish Pirates R.F.C.";
        }

    },
    OLDBELVEDERE {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new OldBelvedere(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Old Belvedere R.F.C.";
        }

    },
    OLDWESLEY {

        @Override
        public TrainingGroup getTrainingGroup() {

            return new OldWesley(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Old Wesley R.F.C.";
        }

    },
    BEDFORDBLUES {

        @Override
        public TrainingGroup getTrainingGroup() {

            

            return new BedfordBlues(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Bedford Blues R.F.C.";
        }

    },
    EXMOUTH {

        @Override
        public TrainingGroup getTrainingGroup() {

            

            return new Exmouth(generateNumber());

        }

        /**
         *
         * @return clubStaffs for all ClubStaff sub-types
         */
        @Override
        public League whichLeague() {

            return League.FIRST;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Exmouth R.F.C.";
        }

    },
    SALESHARKS {

        @Override
        public TrainingGroup getTrainingGroup() {

           

            return new SaleSharks(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Sale Sharks R.F.C.";
        }

    },
    WORCESTERWARRIORS {

        @Override
        public TrainingGroup getTrainingGroup() {

           

            return new WorcesterWarriors(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "WorcesterWarriors R.F.C.";
        }

    },
    ULSTERRUGBY {

        @Override
        public TrainingGroup getTrainingGroup() {

            

            return new UlsterRugby(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Ulster Rugby R.F.C.";
        }

    },
    NEWCASTLEFALCONS {

        @Override
        public TrainingGroup getTrainingGroup() {

           

            return new NewCastleFalcons(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "New Castle Falcons R.F.C.";
        }

    },
    NORTHAMPTONSAINTS {

        @Override
        public TrainingGroup getTrainingGroup() {

            

            return new NorthamptonSaints(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Northampton Saints R.F.C.";
        }

    },
    WANDERERS {

        @Override
        public TrainingGroup getTrainingGroup() {

            

            return new Wanderers(generateNumber());

        }

        /**
         *
         * @return secondLeagues for all SECOND sub-types
         */
        @Override
        public League whichLeague() {

            return League.SECOND;
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "Wanderers R.F.C.";
        }

    };

    public abstract TrainingGroup getTrainingGroup();

    public abstract League whichLeague();

    
    //assigning the number of players inside the group
    private static int generateNumber() {

        Random r = new Random();//instance of random class
        int low = 15;
        int high = 30;
        int randomNo = r.nextInt(high - low) + low;

        return randomNo;
    }

    //@return arraylist of only firstLeague teams
    public static ArrayList<TrainingGroupType> listFirst() {

        TrainingGroupType[] allTypes = TrainingGroupType.values();
        ArrayList<TrainingGroupType> firstLeagues = new ArrayList<TrainingGroupType>();

        for (TrainingGroupType t : allTypes) {

            if (t.whichLeague() == League.FIRST) {
                firstLeagues.add(t);
            }
        }

        return firstLeagues;
    }

    //@return arraylist of only secondLeagueteams
    public static ArrayList<TrainingGroupType> listSecond() {

        TrainingGroupType[] allTypes = TrainingGroupType.values();
        ArrayList<TrainingGroupType> secondLeagues = new ArrayList<TrainingGroupType>();

        for (TrainingGroupType t : allTypes) {

            if (t.whichLeague() == League.SECOND) {
                secondLeagues.add(t);
            }
        }

        return secondLeagues;
    }

    /**
     *
     * @return All available types as a formatted multi-line String
     */
    public static String listTrainingGroupTypesAsString() {

        String list = "";
        TrainingGroupType[] types = TrainingGroupType.values();

        for (int counter = 0; counter < types.length; counter++) {

            list = list.concat((counter + 1) + ": " + types[counter].toString() + " \n");
        }

        return list;
    }

}
