/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClubStaff;

import Staff.StaffType;
import Staff.ClubStaff;

/**
 *
 * Janitor extends ClubStaff
 * 
 * @author Tolga Baris Pinar
 */
public class Janitor extends ClubStaff {

    public Janitor(String firstname, String surname) {
        super(firstname, surname, StaffType.JANITOR);
    }

   
}
    
  