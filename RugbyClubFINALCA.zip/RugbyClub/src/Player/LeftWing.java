/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Player;

/**
 * 
 * LeftWing extends Player
 *
 * @author Tolga Baris Pinar
 */
public class LeftWing extends Player{
    
    public LeftWing(String firstname, String surname) {
        super(firstname, surname, PlayerType.LEFTWING);
    }
    
}
