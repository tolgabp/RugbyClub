/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Staff;

import java.util.ArrayList;
import java.util.Random;

import Exceptions.NoSuchStaffTypeException;

/**
 *
 * Generate a random Staff from a random department
 *
 * @author Tolga Baris Pinar
 */
public class StaffFactory {

    private static StaffType[] allStaffTypes;

    public StaffFactory() {

        this.allStaffTypes = StaffType.values();

    }

    /**
     * Generate a random Staff from a random department
     *
     * @return the StaffMember generated
     */
    public Staff getStaff() {

        Department[] allDepts = Department.values();
        Random r = new Random();

        int randomDeptNo = r.nextInt(allDepts.length);

        return getStaff(allDepts[randomDeptNo]);
    }

    /**
     *
     * @param dept the department specified
     * @return a random staff member from department @param dept
     */
    public Staff getStaff(Department dept) {

        ArrayList<StaffType> someTypes = new ArrayList<StaffType>();
        Random r = new Random();

        someTypes = dept.listAllTypes();

        /**
         * 
         *checks whether the value of Staff.numHeadCoach.
         *If it is, it picks a head coach so that one can have at least one.
         * 
         * 
         */
       
        int randomNo = r.nextInt(Staff.numHeadCoach < 1 ? someTypes.size() : someTypes.size() - 1);

        Staff selected = someTypes.get(randomNo).getStaff();

        return selected;
    }

    /**
     * Create a Staffs of a specified type
     *
     * @param type - the StaffType required
     * @return the staff generated
     */
    private Staff getStaff(StaffType type) {

        return type.getStaff();
    }

    /**
     *
     * @return a formatted list of all available departments
     */
    public String listDepartments() {

        String depts = "";
        int counter = 1;

        for (Department d : Department.values()) {

            depts = depts.concat(counter + ": " + d.toString() + "\n");
            counter++;
        }

        return depts;
    }

    /**
     * Creates a staff based on the type requested
     *
     * @param typeAsString - the StaffType required, as a String
     * @return the Staff generated
     * @throws NoSuchStaffTypeException if there is no type matching the request
     */
    public Staff getStaff(String typeAsString) throws NoSuchStaffTypeException {

        int counter = 0;

        while ((counter < allStaffTypes.length) && (!typeAsString.equalsIgnoreCase(allStaffTypes[counter].toString()))) {

            counter++;
        }

        if (typeAsString.equalsIgnoreCase(allStaffTypes[counter].toString())) {

            return getStaff(allStaffTypes[counter]);
        } else {

            throw new NoSuchStaffTypeException();
        }
    }

}
