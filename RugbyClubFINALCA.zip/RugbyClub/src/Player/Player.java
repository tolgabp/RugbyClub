/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Player;

import java.util.Random;

/**
 *
 * @author Tolga Baris Pinar
 */
public class Player {

    /**
     *
     *
     * All player has a player number as well as basic personal details
     *
     * They have a position
     *
     *
     */
    private String firstname;
    private String surname;
    private int age;
    private int numOfPlayer;
    private PlayerType position; //specific role

    private static int currentPlayerNumber = 1;

    public Player(String firstname, String surname, PlayerType position) {

        this.firstname = firstname;
        this.surname = surname;
        this.age = getRandomAge();
        this.numOfPlayer = generateNumPlayer(); //when a player is joined the club, they get a number.
        this.position = position;

    }

    //generate player number
    private int generateNumPlayer() {

        return this.currentPlayerNumber++;

    }

    @Override
    //return the staff member's name in full
    public String toString() {

        return "\n********* \nPlayer Number: " + this.numOfPlayer
                + "\nFirst name: " + this.firstname
                + "\nSurname: " + this.surname
                + "\nRole: " + this.position
                + "\nAge: "+this.age;
    }
    

    public String getFirstname() {
        return firstname;
    }

    public String getSurname() {
        return surname;
    }

    public int getAge() {
        return age;
    }

    public int getNumOfPlayer() {
        return numOfPlayer;
    }

    public PlayerType getPosition() {
        return position;
    }

    
    //get random age for players
    public int getRandomAge() {

        Random rand = new Random();
        int randomInt = rand.nextInt(11) + 15;  // generates a number between 0 and 10, then adds 15
        randomInt = this.age;
        return this.age;
    }
}
