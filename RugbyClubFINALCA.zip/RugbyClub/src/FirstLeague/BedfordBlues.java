/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FirstLeague;

import TrainingGroup.FirstLeague;
import TrainingGroup.TrainingGroupType;

/**
 * 
 * BedfordBlues extends FirstLeague
 *
 * @author Tolga Baris Pinar
 */
public class BedfordBlues extends FirstLeague{
    
    public BedfordBlues(int numOfPlayers) {
        super(numOfPlayers, TrainingGroupType.BEDFORDBLUES);
    }
    
   
    
}
