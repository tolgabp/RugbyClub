/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Staff;

import java.util.Random;

/**
 *
 * @author Tolga Baris Pinar
 */
public abstract class CoachingStaff extends Staff {

    //qualification level of coaches
    protected int qLvl;

    public CoachingStaff(String firstname, String surname, StaffType role) {
        super(firstname, surname, Department.COACHINGSTAFF, role);

        //only a head coach's qualification level can be 5
        if (role == StaffType.HEADCOACH) {
            this.qLvl = 5;
        } else {
            this.qLvl = generateQLvl(); //random qualification level generator
        }
    }

    public CoachingStaff() {
        super();
    }

    /**
     * As there is a difference between club staff and coaching staff, it should
     * be put in the sub class of the parent class.
     *
     */
    @Override
    //return the Coaching staff member's name in full
    public String toString() {

        return "\n********* \nStaff ID: " + this.getStaff_ID()
                + "\nFirstname: " + this.getfirstName()
                + "\nSurname: " + this.getSurname()
                + "\nRole: " + this.getRole().toString()
                + "\nQualification Level: " + this.qLvl;
    }

    //all coaches except the head coach should have qualification level between 1 and four(inclusively)
    private int generateQLvl() {

        Random rand = new Random(); //instance of random class

        int randomQLvl;
        //generate random values from 1-5 
        return randomQLvl = rand.nextInt(5 - 1) + 1;

    }

}
