package Exceptions;

/**
 * 
 * exception file in case of facing an error in searching process
 * 
 * @author Tolga Baris Pinar
 */

public class SearchException extends Exception {

	public SearchException() {
		
          
	}

	public SearchException(String message) {
            
		super("Search Error: " + message);
		
	}

	public SearchException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SearchException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SearchException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
