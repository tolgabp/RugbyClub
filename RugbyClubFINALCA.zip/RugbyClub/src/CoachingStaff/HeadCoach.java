/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CoachingStaff;

import Staff.CoachingStaff;
import Staff.StaffType;

/**
 *
 * HeadCoach extends CoachingStaff
 * 
 * @author Tolga Baris Pinar
 */
public class HeadCoach extends CoachingStaff {


    public HeadCoach(String firstname, String surname) {
        super(firstname, surname, StaffType.HEADCOACH);

    }


    //no args constructor
    public HeadCoach() {

        super();

    }

}
