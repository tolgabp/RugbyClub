/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package TrainingGroup;


import java.util.ArrayList;

/**
 *
 * @author Tolga Baris Pinar
 */
public enum League {
    
    FIRST{
        @Override
        public TrainingGroup getTrainingGroup(TrainingGroupType groupType) {

            return groupType.getTrainingGroup();
        }

        @Override
        public ArrayList<TrainingGroupType> listAllTypes() {

            return TrainingGroupType.listFirst();
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "FIRST League";
        }
    
    
    },
    
    SECOND{
        @Override
        public TrainingGroup getTrainingGroup(TrainingGroupType groupType) {

            return groupType.getTrainingGroup();
        }

        @Override
        public ArrayList<TrainingGroupType> listAllTypes() {

            return TrainingGroupType.listSecond();
        }

        @Override
        public String toString() {
            // TODO Auto-generated method stub
            return "SECOND League";
        }
    
    
    
    
    };
    
    //@return a Training group of a specific type
    public abstract TrainingGroup getTrainingGroup(TrainingGroupType groupType);

    public abstract ArrayList<TrainingGroupType> listAllTypes();

    public abstract String toString();
    
    
}
