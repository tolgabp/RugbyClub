/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Player;

import Exceptions.NoSuchPlayerTypeException;

import java.util.Random;

/**
 *
 * @author Tolga Baris Pinar
 */
public class PlayerFactory {

    private static PlayerType[] allStaffTypes;

    public PlayerFactory() {

        this.allStaffTypes = PlayerType.values();

    }

    /**
     * Generate a random Player from a random PlayerType
     *
     * @return the Player generated
     */ 
    
    
    public Player getPlayer() {

        PlayerType[] allPlayers = PlayerType.values();
        Random r = new Random();

        int randomDeptNo = r.nextInt(allPlayers.length);

        return getPlayer(allPlayers[randomDeptNo]);
    }
    
    
    /**
     * Create a Player of a specified type
     *
     * @param type - the PlayerType required
     * @return the Player generated
     */
    private Player getPlayer(PlayerType type) {

        return type.getPlayer();
    }
    
    /**
     *
     * @return a formatted list of all available Types
     */
    public String listType() {

        String type = "";
        int counter = 1;

        for (PlayerType pt : PlayerType.values()) {

            type = type.concat(counter + ": " + pt.toString() + "\n");
            counter++;
        }

        return type;
    }

    /**
     * Creates a player based on the type requested
     *
     * @param typeAsString - the PlayerType required, as a String
     * @return the Player generated
     * @throws NoSuchStaffTypeException if there is no type matching the request
     */
    public Player getPlayer(String typeAsString) throws NoSuchPlayerTypeException {

        int counter = 0;

        while ((counter < allStaffTypes.length) && (!typeAsString.equalsIgnoreCase(allStaffTypes[counter].toString()))) {

            counter++;
        }

        if (typeAsString.equalsIgnoreCase(allStaffTypes[counter].toString())) {

            return getPlayer(allStaffTypes[counter]);
        } else {

            throw new NoSuchPlayerTypeException();
        }
    }
    

}
