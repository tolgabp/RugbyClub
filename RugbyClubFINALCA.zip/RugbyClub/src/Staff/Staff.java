/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Staff;

/**
 *
 * @author Tolga Baris Pinar
 */
public abstract class Staff {

    /*
	 * All staff has a staff ID as well as basic personal details
	 * 
	 * They are all assigned to a Dept and have a rol
	 * 
     */
    private String firstname;
    private String surname;
    private int staff_ID;
    private Department dept; //the department they work in
    private StaffType role;  //specific role (or job title)

    private static int currentStaffNumber = 1000;	//Start the staff ID badges at 1000

    public static int numHeadCoach = 0; //To keep the numbers of head coach

    //To hire a new staff member you need their name, the department where they will work, and their job title (role)
    public Staff(String firstname, String surname, Department dept, StaffType role) {

        //ensures creating at least one head coach
        if ((role == StaffType.HEADCOACH && Staff.numHeadCoach < 1) || role != StaffType.HEADCOACH) {

            this.firstname = firstname;
            this.surname = surname;
            this.staff_ID = generateIDBadge();	//when a new staff member is hired, they get a ID number.
            this.dept = dept;
            this.role = role;

            //prevents creating more than one head coach
            if (role == StaffType.HEADCOACH) {
                Staff.numHeadCoach++;
            }

        } else {
            System.out.println("There can only be one HEAD COACH!");

        }

    }

    public Staff() {
    }

    private int generateIDBadge() {

        //Note -- A more complex ID creation method could be performed here.
        this.currentStaffNumber++;
        return this.currentStaffNumber;

    }

    public StaffType getRole() {

        return this.role;
    }

    public String getfirstName() {

        return this.firstname;
    }

    public String getSurname() {

        return this.surname;
    }

    public int getStaff_ID() {
        return staff_ID;
    }

    public void displayStaff() {
        System.out.println("First Name: " + this.firstname + "\nSurname: " + this.surname + "\nStaff ID: " + this.staff_ID + "\n");
    }

    public void displayStaffList(int index) {
        System.out.println(index + "-) " + "First Name: " + this.firstname + "\nSurname: " + this.surname + "\nStaff ID: " + this.staff_ID + "\n");
    }

}
