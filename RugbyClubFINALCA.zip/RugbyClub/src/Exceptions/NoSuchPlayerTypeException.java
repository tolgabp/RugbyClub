/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exceptions;

/**
 *
 * exception file in case of no such player
 * 
 * @author Tolga Baris Pinar
 */
public class NoSuchPlayerTypeException extends Exception{
    
    
    public NoSuchPlayerTypeException(){
        
        super("There is no such player position available at this time.");
    
    }
    
    public NoSuchPlayerTypeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSuchPlayerTypeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchPlayerTypeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchPlayerTypeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
    
    
    
}


