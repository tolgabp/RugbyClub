/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainingGroup;

/**
 * SecondLeague extends TrainingGroup
 *
 * @author Tolga Baris Pinar
 */
public abstract class SecondLeague extends TrainingGroup {
    
    public SecondLeague(int numOfPlayers, TrainingGroupType groupType) {
        super(numOfPlayers, League.SECOND, groupType);
    }
    
    
    
    
    
    
    
}
