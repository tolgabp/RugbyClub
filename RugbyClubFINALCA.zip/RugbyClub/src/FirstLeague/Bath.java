/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FirstLeague;

import TrainingGroup.FirstLeague;
import TrainingGroup.TrainingGroupType;

/**
 * 
 * Bath extends FirstLeague
 *
 * @author Tolga Baris Pinar
 */
public class Bath extends FirstLeague{
    
    public Bath(int numOfPlayers) {
        super(numOfPlayers, TrainingGroupType.BATH);
    }
    
   
    
}
