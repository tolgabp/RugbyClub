/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Player;

/**
 * 
 * LooseHeadProp extends Player
 *
 * @author Tolga Baris Pinar
 */
public class LooseHeadProp extends Player{
    
    public LooseHeadProp(String firstname, String surname) {
        super(firstname, surname, PlayerType.LOOSEHEADPROP);
    }
    
}
