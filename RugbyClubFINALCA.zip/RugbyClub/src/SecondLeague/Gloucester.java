/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SecondLeague;

import TrainingGroup.League;
import TrainingGroup.SecondLeague;
import TrainingGroup.TrainingGroupType;

/**
 * 
 * Gloucester extends SecondLeague
 *
 * @author Tolga Baris Pinar
 */
public class Gloucester extends SecondLeague{
    
    public Gloucester(int numOfPlayers) {
        super(numOfPlayers, TrainingGroupType.GLOUCESTER);
    }
    

    
    
}
