/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FirstLeague;

import TrainingGroup.FirstLeague;
import TrainingGroup.TrainingGroupType;

/**
 *
 * BristolBears extends FirstLeague
 * 
 * @author Tolga Baris Pinar
 */
public class BristolBears extends FirstLeague {
    
    public BristolBears(int numOfPlayers) {
        super(numOfPlayers, TrainingGroupType.BRISTOLBEARS);
    }
    
  
    
}
