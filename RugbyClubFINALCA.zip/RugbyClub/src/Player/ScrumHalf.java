/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Player;

/**
 * 
 * ScrumHalf extends Player
 *
 * @author Tolga Baris Pinar
 */
public class ScrumHalf extends Player{
    
    public ScrumHalf(String firstname, String surname) {
        super(firstname, surname, PlayerType.SCRUMHALF);
    }
    
}
