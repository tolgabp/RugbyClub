/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SecondLeague;

import TrainingGroup.League;
import TrainingGroup.SecondLeague;
import TrainingGroup.TrainingGroupType;

/**
 * 
 * Wasps extends SecondLeague
 *
 * @author Tolga Baris Pinar
 */
public class Wasps extends SecondLeague {
    
    public Wasps(int numOfPlayers) {
        super(numOfPlayers,  TrainingGroupType.WASPS);
    }
    
    
}
