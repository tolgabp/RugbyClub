package Menu;

import Staff.Staff;
import Staff.StaffType;
import TrainingGroup.League;
import java.util.ArrayList;
import java.util.Scanner;
import rugbyclub.RugbyClub;

/**
 * Allows a menu to be created
 *
 * @author tolgabarisp
 */
public class Menu {

    // created RugbyClub object to call its methods
    RugbyClub clubCaller = new RugbyClub();
    //menu options string array
    private String[] optionList;

    public Menu() {
    }

    public void menuDisplay() {
        boolean optionVal = false;// do loop guard for the main menu
        boolean optionVal2 = false;// do loop guard for the first sub-menu
        boolean optionVal3 = false;// do loop guard for the second sub-menu
        boolean optionVal4 = false;// do loop guard for the third sub-menu

        String choice; //scanner string for the menu
        String choiceSub; //scanner string for the first sub-menu
        String choiceSub2;// scanner string for the second sub-menu
        String choiceSub3;// scanner string for the third sub-menu

        Scanner myKB = new Scanner(System.in); //created the input reader

        //used do while in order to print out the menu at least once
        do {

            // displaying the menu
            System.out.println(
                    "Press 1 – List all staff \n"
                    + "Press 2 – List staff by a category chosen by the user (e.g. list all Assistant Coaches) \n"
                    + "Press 3 – List all Groups, showing the coach and the number of players in the group \n"
                    + "Press 4 – List Groups by the day they train (e.g. list all who train on Monday) \n"
                    + "Press 5 - List all the players in a particular League \n"
                    + "Press 6 – List the players coached by a particular coach \n"
                    + "Press 7 – List all players in the club \n"
                    + "Press 8 – Exit"
                    + "\nPress the number of option according to your wish: \n");

            choice = myKB.nextLine(); //input

            System.out.println("\n");

            switch (choice) {
                case "1":
                    System.out.println(clubCaller.listAllStaff() + "\n"); //List all staff
                    break;
                case "2":

                    do {
                        //list all staff types
                        System.out.println(clubCaller.getStaffTypes() + "7 - Return to main menu \n");
                        System.out.println("Please choose a category: \n");
                        choiceSub = myKB.nextLine(); //input
                        System.out.println("\n");

                        switch (choiceSub) {

                            case "1":
                                displayStaffByCategory(StaffType.GROUNDSTAFF);//list all GROUNDSTAFF
                                break;
                            case "2":
                                displayStaffByCategory(StaffType.JANITOR); //list all JANITOR
                                break;
                            case "3":
                                displayStaffByCategory(StaffType.RECEPTIONIST);//list all RECEPTIONIST
                                break;
                            case "4":
                                displayStaffByCategory(StaffType.ASSISTANTCOACH);//list all ASSISTANTCOACH
                                break;
                            case "5":
                                displayStaffByCategory(StaffType.STAMINACOACH);//list all STAMINACOACH
                                break;
                            case "6":
                                displayStaffByCategory(StaffType.HEADCOACH);//list all HEADCOACH
                                break;
                            case "7":
                                optionVal2 = true;//to exit the loop
                                break;
                            default:
                                System.out.println("Invalid request - must enter 1, 2, 3, 4, 5, 6, 7 \n");
                                break;
                        }
                    } while (!optionVal2);

                    break;
                case "3":
                    System.out.println(clubCaller.listAllTrainingGroup() + "\n");
                    break;
                case "4":
                    displayGroupByDayTrain();
                    break;
                case "5":
                    do {
                        System.out.println("1 - Display First League Players");
                        System.out.println("2 - Display Second League Players");
                        System.out.println("3 - Return to main menu");
                        System.out.println("Please choose a category: \n");
                        choiceSub2 = myKB.nextLine();
                        System.out.println("\n");

                        switch (choiceSub2) {

                            case "1":
                                displayLeaguePlayer(League.FIRST);
                                break;
                            case "2":
                                displayLeaguePlayer(League.SECOND);
                                break;
                            case "3":
                                optionVal3 = true;//to exit the loop
                                break;
                            default:
                                System.out.println("Invalid request - must enter 1, 2, 3 \n");
                                break;
                        }
                    } while (!optionVal3);

                    break;
                case "6":
                    ArrayList<Staff> coachList = clubCaller.getCoachList();

                    do {
                        System.out.println("\n0 - Return to main menu\n");

                        int index = 1;
                        for (Staff staff : coachList) {
                            staff.displayStaffList(index);
                            index++;
                        }

                        System.out.println("Please choose a category: \n");
                        choiceSub3 = myKB.nextLine();
                        System.out.println("\n");

                        if (Integer.parseInt(choiceSub3) < coachList.size() && Integer.parseInt(choiceSub3) != 0) {
                            displayPlayerByCoach(coachList.get(Integer.parseInt(choiceSub3) - 1));
                        } else if (Integer.parseInt(choiceSub3) == 0) {
                            optionVal4 = true;//to exit the loop
                        } else {
                            System.out.println("Invalid request\n");
                        }

                    } while (!optionVal4);

                    break;
                case "7":
                    System.out.println(clubCaller.listAllPlayer() + "\n");
                    break;
                case "8":
                    optionVal = true; //to exit the loop
                    System.exit(0); //to exit the program
                    break;
                default:
                    System.out.println("Invalid request - must enter 1, 2, 3, 4, 5, 6, 7, 8 \n");
                    break;

            }
            System.out.println(choice);

        } while (!optionVal);
    }

    //A method that stores options inside a string array
    public Menu(String[] options) {

        this.optionList = options;
    }

    //A method that stores options inside a string arraylist
    public Menu(ArrayList<String> options) {

        this.optionList = new String[options.size()];
        for (int i = 0; i < this.optionList.length; i++) {

            this.optionList[i] = options.get(i).toString();
        }

    }

    
    //A method that puts menu options together
    public String showMenu(String header) {

        String menu = "***** " + header + " ******** \n";

        for (int count = 0; count < optionList.length; count++) {

            menu = menu.concat("\n" + count + ") " + optionList[count] + ".");
        }

        return menu;
    }

    //A method that displays StaffByCategory
    public void displayStaffByCategory(StaffType type) {

        clubCaller.displayStaff(type);

    }
    //A method that displays GroupByDAyTrain
    public void displayGroupByDayTrain() {

        clubCaller.displayGroupByDayTrain();
    }
    //A method that displays LeaguePlayer
    public void displayLeaguePlayer(League league) {
        clubCaller.displayLeaguePlayer(league);
    }

    //A method that displays PlayerByCoach
    public void displayPlayerByCoach(Staff coach) {
        clubCaller.displayPlayerByCoach(coach);
    }
}
