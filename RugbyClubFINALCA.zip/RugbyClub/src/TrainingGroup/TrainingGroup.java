/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TrainingGroup;

import Player.Player;
import Staff.Staff;
import java.util.ArrayList;

/**
 * 
 * All training group has basic information.
 * 
 * They are all assigned to a league
 *
 * @author Tolga Baris Pinar
 */
public abstract class TrainingGroup {

    
    private TrainingGroupType groupType;
    private int numOfPlayers;
    private League league;
    private String trainingDay;
    private Staff coach;
    private ArrayList<Player> groupPlayers = new ArrayList<Player>();

    public TrainingGroup(int numOfPlayers, League league, TrainingGroupType groupType) {

        this.numOfPlayers = numOfPlayers;
        this.league = league;
        this.groupType = groupType;
    }

    
    @Override
    //return the trainingGroup's name in full
    public String toString() {

        return "\n********* \nLeague: " + this.league.toString() + "\nTraining Group: \n" + this.groupType
                + "\nNumber of Players: " + this.numOfPlayers;
                
                
        

    }

    

    public TrainingGroupType getGroupType() {
        return groupType;
    }

    public int getNumOfPlayers() {
        return numOfPlayers;
    }
    
    public void setTrainingDay(String trainingDay) {
        this.trainingDay = trainingDay;
    }
   
     public String getTrainingDay() {
        return trainingDay;
    }

    public League getLeague() {
        return league;
    }

    public void setCoach(Staff coach) {
        this.coach = coach;
    }

    public void addGroupPlayer(Player groupPlayer) {
        this.groupPlayers.add(groupPlayer);
    }

    public Staff getCoach() {
        return coach;
    }

    public ArrayList<Player> getGroupPlayers() {
        return groupPlayers;
    }
    
    
    


}
