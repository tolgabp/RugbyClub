/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Player;

/**
 * 
 * RightWing extends Player
 *
 * @author Tolga Baris Pinar
 */
public class RightWing extends Player{
        
    public RightWing(String firstname, String surname) {
        super(firstname, surname, PlayerType.RIGHTWING);
    }
        
}
