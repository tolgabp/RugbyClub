/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClubStaff;

import Staff.StaffType;
import Staff.ClubStaff;

/**
 *
 * Receptionist extends ClubStaff
 * 
 * @author Tolga Baris Pinar
 */
public class Receptionist extends ClubStaff {
    
    public Receptionist(String firstname, String surname) {
        super(firstname, surname, StaffType.RECEPTIONIST);
    }
    
 
    
    

    
    
}
